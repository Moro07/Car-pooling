<?php

namespace Controller;

use Model\AutistaRepository;
use Psr\Container\ContainerInterface;
use Slim\Psr7\Request;
use Slim\Psr7\Response;

class AutistaController
{

    private $container;

    // constructor receives container instance
    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }

    public function listAll(Request $request, Response $response, array $args): Response
    {
        $engine = $this->container->get('template');
        $autisti = AutistaRepository::listAll();
        $response->getBody()->write($engine->render('autisti',
            [
                'autisti' => $autisti,

            ]
        ));
        return $response;
    }

    public function showAutista(Request $request, Response $response, array $args): Response
    {
        $engine = $this->container->get('template');
        $autista = AutistaRepository::getAutista($args['id']);
        $response->getBody()->write($engine->render('autista',
            [
                'autista' => $autista,

            ]
        ));
        return $response;
    }

}