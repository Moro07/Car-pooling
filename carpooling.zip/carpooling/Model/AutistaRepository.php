<?php

namespace Model;

use Util\Connection;

class AutistaRepository{

    public static function listAll(){
        $pdo = Connection::getInstance();
        $risposta = $pdo->query("SELECT * FROM autista");
        return $risposta->fetchAll();
    }

    public static function getAutista(int $id)
    {
        $pdo = Connection::getInstance();
        $risposta = $pdo->prepare('SELECT * FROM autista WHERE idAutista = :id');
        $risposta->execute([
            'id' => $id
        ]);
        return $risposta->fetch();
    }

}