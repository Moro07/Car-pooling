<?php
/**
 * @var $autisti
 */
?>
<?php $this->layout('home', ['title' => 'Autisti']) ?>

<h1>Lista degli autisti: </h1>
<ul>
    <table border="">
        <tr style="font-weight: bold"><td>Id</td><td>Cognome</td><td>Nome</td><td>Data di nascita</td><td>Sesso</td><td>Numero di patente</td><td>Data di scadenza della patente</td><td>Targa</td><td>Modello</td><td>Numero di telefono</td><td>Email</td><td>Foto</td><td>Voto medio</td></tr>
        <?php foreach ($autisti as $autista): ?>
        <tr><td><?=$autista['idAutista']?></td><td><a href="<?=$base_path?>/autisti/autista/<?=$autista['idAutista']?>"><?=$autista['cognome']?></a></td><td><?=$autista['nome']?></td><td><?=$autista['dataNascita']?></td><td><?=$autista['sesso']?></td><td><?=$autista['nPatente']?></td><td><?=$autista['dataScadenza']?></td><td><?=$autista['targa']?></td><td><?=$autista['modello']?></td><td><?=$autista['nTelefono']?></td><td><?=$autista['email']?></td><td><?=$autista['foto']?></td><td><?=$autista['votoMedio']?></td></tr>
        <?php endforeach;?>
    </table>
</ul>