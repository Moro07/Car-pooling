<?php
/**  @var $title
 *   @var $base_path

 */ ?>
<!doctype html>
<html lang="it">
<head>
    <link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre.min.css">
    <link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre-exp.min.css">
    <link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre-icons.min.css">
    <title><?=$this->e($title)?></title>
</head>
<body>

<div class="container grid-xl">
    <header class="navbar">
        <section class="navbar-section">

        </section>
        <!--<section class="navbar-section">
            <div class="input-group input-inline">
                <input class="form-input" type="text" placeholder="search">
                <button class="btn btn-primary input-group-btn">Search</button>
            </div>
        </section>-->
    </header>
<!--Questa parte sarà sempre così e serve a includere
il template che contiene il contenuto vero e proprio-->
<?=$this->section('content')?>
</div>
</body>
</html>
