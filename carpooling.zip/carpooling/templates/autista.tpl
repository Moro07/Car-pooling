<?php
/**
 * @var $autista
 */
?>
<?php $this->layout('home', ['title' => 'Autista']) ?>

<h1>Autista</h1>

<div class="card">

    <div class="card-body">
        <div style="font-weight: bold">Id autista: </div><?=$autista['idAutista']?><br>
        <div style="font-weight: bold">Cognome: </div><?=$autista['cognome']?><br>
        <div style="font-weight: bold">Nome: </div><?=$autista['nome']?><br>
        <div style="font-weight: bold">Data di nascita: </div><?=$autista['dataNascita']?><br>
        <div style="font-weight: bold">Sesso: </div><?=$autista['sesso']?><br>
        <div style="font-weight: bold">Numero di patente: </div><?=$autista['nPatente']?><br>
        <div style="font-weight: bold">Data di scadenza della patente: </div><?=$autista['dataScadenza']?><br>
        <div style="font-weight: bold">Targa: </div><?=$autista['targa']?><br>
        <div style="font-weight: bold">Modello: </div><?=$autista['modello']?><br>
        <div style="font-weight: bold">Numero di telefono: </div><?=$autista['nTelefono']?><br>
        <div style="font-weight: bold">Email: </div><?=$autista['email']?><br>
        <div style="font-weight: bold">Foto: </div><?=$autista['foto']?><br>
        <div style="font-weight: bold">Voto medio: </div><?=$autista['votoMedio']?><br>
    </div>
    <div class="card-footer">
        <a href="<?=$base_path?>/autisti">Torna alla lista degli autisti</a>
    </div>
</div>